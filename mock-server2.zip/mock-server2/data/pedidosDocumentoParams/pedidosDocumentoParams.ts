

module.exports = {
    fnc(req) {

        // Opções de retorno de Dados
        const typeReponse = {
            SucessDataValue: 'SucessDataValue', //  retorno padrão com sucesso e com lista de dados preenchidos.
            SucessDataEmpty: 'SucessDataEmpty', //  retorno alternativo com sucesso e com lista de dados vazia.
            ErrorDataValue: 'ErrorDataValue', // retorno alternativo com erro e com objeto de erro preenchido.
            ErrorDataEmpty: 'ErrorDataEmpty' // retorno alternativo com erro e com objeto de erro vazio
        };

        // tslint:disable-next-line: prefer-const
        let typeReponseData = typeReponse.SucessDataValue;

        // Opções de tempo para execução o endpopint em segundos
        const timeResponse = {
            timeDefault: 0, // retorno padrão e rápido sem timeout.
            timeOptional2000: 2000, // retorno alternativo com timeout curto.
            timeOptional5000: 5000 // retorno alternativo com timeout longo.
        };
        // tslint:disable-next-line: prefer-const
        let timeResponseData = timeResponse.timeDefault;

        let messageError = 'Sua consulta não retornou registros';
        let dataResponse;
        let statusResponse = 200;

        // if (!param.numCotacao) {
        //     typeReponseData = typeReponse.ErrorDataValue;
        // }
        if (req && req.codigoPedidoDocumento &&
            +req.codigoPedidoDocumento === 100) {
            typeReponseData = typeReponse.ErrorDataValue;
            messageError = `Não foi possível obter dados do pedido ${req.codigoPedidoDocumento}`;
        }

        switch (typeReponseData) {

            case 'SucessDataValue':

                if (req) {
                    if ((+req.codigoPedidoDocumento)
                    ) {
                        dataResponse = require('./pedidosDocumentoParams.json');
                    }
                }
                break;

            case 'SucessDataEmpty':
                dataResponse = [];
                break;

            case 'ErrorDataValue':
                statusResponse = 400;
                dataResponse = {
                    error: {
                        mensagens: [
                            {
                                codigo: statusResponse,
                                mensagem: messageError
                            }
                        ],
                        dataOcorrencia: new Date().toString(),
                        fonte: 'error.generalError',
                        tipo: 'SISTEMA',
                        additionalInfo: null
                    }
                };
                break;

            case 'ErrorDataEmpty':
                statusResponse = 500;
                dataResponse = {};
                break;

            default:

        }
        return {
            timeResponse: timeResponseData,
            statusResponse,
            dataResponse
        };
    }
};
