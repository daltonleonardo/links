

module.exports = {
    fnc(req) {

        enum typeOperator {
            greaterThanOrEqualTo = 'greaterThanOrEqualTo',
            lessThanOrEqualTo = 'lessThanOrEqualTo'
        }

        function CompareDate(dateStart: string, dateEnd: string, operator: typeOperator): boolean {
            const timeStart = new Date(dateStart).getTime();
            const timeEnd = new Date(dateEnd).getTime();

            switch (operator) {
                case 'greaterThanOrEqualTo':
                    return timeStart >= timeEnd;
                case 'lessThanOrEqualTo':
                    return timeStart <= timeEnd;
                default:
                    throw new Error('Unrecognized Operator');

            }

        }

        // Opções de retorno de Dados
        const typeReponse = {
            SucessDataValue: 'SucessDataValue', //  retorno padrão com sucesso e com lista de dados preenchidos.
            SucessDataEmpty: 'SucessDataEmpty', //  retorno alternativo com sucesso e com lista de dados vazia.
            ErrorDataValue: 'ErrorDataValue', // retorno alternativo com erro e com objeto de erro preenchido.
            ErrorDataEmpty: 'ErrorDataEmpty' // retorno alternativo com erro e com objeto de erro vazio
        };

        // tslint:disable-next-line: prefer-const
        let typeReponseData = typeReponse.SucessDataValue;

        // Opções de tempo para execução o endpopint em segundos
        const timeResponse = {
            timeDefault: 0, // retorno padrão e rápido sem timeout.
            timeOptional2000: 2000, // retorno alternativo com timeout curto.
            timeOptional5000: 5000 // retorno alternativo com timeout longo.
        };
        // tslint:disable-next-line: prefer-const
        let timeResponseData = timeResponse.timeDefault;

        let messageError = 'Sua consulta não retornou registros';
        let dataResponse;
        let statusResponse = 200;

        if (req && req.filtroNumeroPedido &&
            +req.filtroNumeroPedido === 100) {
            typeReponseData = typeReponse.ErrorDataValue;
            messageError = `Não foi possível obter dados do pedido ${req.filtroNumeroPedido}`;
        }


        switch (typeReponseData) {

            case 'SucessDataValue':

                if (req) {
                    // console.log('+param.query.filtroNumeroPedido: ', +param.filtroNumeroPedido);
                    if ((!req.filtroNumeroPedido ||
                        req.filtroNumeroPedido && +req.filtroNumeroPedido === 5103573) &&
                        // (!param.filtroTipoDocumento ||
                        //     param.filtroTipoDocumento && +param.filtroTipoDocumento === 5103573) && /** Todo De para com o código */
                        (!req.filtroNumeroDocumento ||
                            req.filtroNumeroDocumento && +req.filtroNumeroDocumento === 100) &&
                        (!req.filtroVersaoDocumento ||
                            req.filtroVersaoDocumento && req.filtroVersaoDocumento === `IMP-002`) &&
                        (!req.filtroOrigem ||
                            req.filtroOrigem && 'Nova Plataforma'.toLowerCase().indexOf(req.filtroOrigem.toLowerCase()) > -1) &&
                        (!req.filtroDataPedidoInicio ||
                            req.filtroDataPedidoInicio &&
                            CompareDate(req.filtroDataPedidoInicio, '2014-04-07T13:58:10.104Z', typeOperator.greaterThanOrEqualTo)) &&
                        (!req.filtroDataPedidoFim ||
                            req.filtroDataPedidoFim &&
                            CompareDate(req.filtroDataPedidoFim, '2014-04-07T13:58:10.104Z', typeOperator.lessThanOrEqualTo)) &&
                        (!req.filtroStatusPedido ||
                            req.filtroStatusPedido && +req.filtroStatusPedido === 1) /** Todo De para com o código */
                    ) {

                        dataResponse = require('./pedidosDocumento.json');
                    }
                }
                break;

            case 'SucessDataEmpty':
                dataResponse = [];
                break;

            case 'ErrorDataValue':
                statusResponse = 400;
                dataResponse = {
                    error: {
                        mensagens: [
                            {
                                codigo: statusResponse,
                                mensagem: messageError
                            }
                        ],
                        dataOcorrencia: new Date().toString(),
                        fonte: 'error.generalError',
                        tipo: 'SISTEMA',
                        additionalInfo: null
                    }
                };
                break;

            case 'ErrorDataEmpty':
                statusResponse = 500;
                dataResponse = {};
                break;

            default:

        }
        return {
            timeResponse: timeResponseData,
            statusResponse,
            dataResponse
        };
    }
};
