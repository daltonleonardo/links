

module.exports = () => {
    const data = {
        pedidosDocumento: { data: 'ok' },
        pedidosDocumentoParams: { data: 'ok' }
    };
    return data;
};
