var server = require('mock-json-server');

const app = server({
  '/v1/pedidosdocumento/': {
    get: { data: 'ok' }
  },
  '/v1/pedidosdocumento/:codigoPedidoDocumento': {
    get: { data: 'ok' }
  },
  '/v1/dominios/:codigoDominio': {
    get: { data: 'ok' }
  }
}, 8666, 'localhost');

app.start();
